import re
import shutil

import requests
import scrapy
from bs4 import BeautifulSoup
from scrapy.http.request import Request


class GoogleSpider(scrapy.Spider):

    name = "google"
    next_page_token = None

    HEADERS = {
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36 Edg/87.0.664.66",
        "referer": None,
    }

    def start_requests(self):
        urls = [
            "https://www.google.com/maps/search/B+Laban+Abu+Dhabi/@24.4746884,54.3736111,17z?entry=ttu"
            # "https://www.google.com/search?q=b+laban+abu+dhabi&rlz=1C1UEAD_enBD1015BD1015&oq=b+laban+abu+dhabi&gs_lcrp=EgZjaHJvbWUqCggAEAAY4wIYgAQyCggAEAAY4wIYgAQyEAgBEC4YrwEYxwEYgAQYjgUyBwgCEAAYgAQyBwgDEAAYgAQyBwgEEAAYgAQyBggFEEUYPDIGCAYQRRg8MgYIBxBFGDzSAQgxNjM1ajBqNKgCALACAQ&sourceid=chrome&ie=UTF-8#ip=1&lrd=0x3e5e673674ad5bb5:0xd113e54a272bf2f8,1,,,,"
        ]

        for url in urls:
            # async_id = url.split("lrd=")[1].split(",")[0]
            # ajax_url = (
            #     "https://www.google.com/async/reviewDialog?async=feature_id:"
            #     + str(async_id)
            #     + ",_fmt:pc"  # ,sort_by:newestFirst"
            # )
            ajax_url = url
            yield Request(
                url=ajax_url,
                headers=self.HEADERS,
                callback=self.parse_reviews_new,
                meta={"iter": 1},
            )

    def parse_reviews_new(self, response):
        # View the HTML content of the response
        html_content = response.body
        self.logger.info(f"Received response:\n{html_content.decode()}")

    def download_image(self, reviewer, it, url):
        response = requests.get(url, stream=True)
        with open(f"./images/{reviewer}_{it}.png", "wb") as out_file:
            shutil.copyfileobj(response.raw, out_file)

    def parse_reviews(self, response):
        """
        total_reviews_text = response.css("span.z5jxId::text").extract_first()
        print("REVIEWS:", total_reviews_text)

        if total_reviews_text:
            # Filter out non-digit characters and convert to integer
            total_reviews = int(re.sub(r"[^\d]", "", total_reviews_text))
            print(f"Total Reviews Number: {total_reviews}")

        total_reviews = 31

        temp = total_reviews / 10  # since
        new_num = int(temp)
        if temp > new_num:
            new_num += 1
        iteration_number = new_num

        j = 0
        print("\n\n\n", iteration_number, "\n\n\n")

        # total_reviews = 21
        # iteration_number = 2"""

        iter = response.meta["iter"]
        print("ITER", iter)
        if iter > 0:
            iter -= 1

            all_reviews = response.xpath('//*[@id="reviewSort"]/div/div[2]/div')

            # WRITE CSV OF 10 REVIEWS
            for review in all_reviews:
                reviewer = review.css("div.TSUbDb a::text").extract_first()
                description = review.xpath(
                    './/span[@class="review-full-text"]'
                ).extract_first()

                if description is None:
                    description = review.css(".Jtu6Td span").extract_first()
                    # description = review.xpath(
                    #     './/div[@class=".Jtu6Td"]//span'
                    # ).extract_first()

                    # print(description, "HEHEH")

                    soupDescription = BeautifulSoup(description, "html.parser")
                    # print("\n\n\n", soupDescription, "\n\n\n")
                    if soupDescription:

                        nested_div = soupDescription.find("div", class_="k8MTF")

                        if nested_div:
                            nested_div.decompose()

                        nested_span = soupDescription.find(
                            "span", attrs={"data-ellipsis-for-sq": True}
                        )
                        if nested_span:
                            nested_span.decompose()

                        nested_a = soupDescription.find("a", class_="review-more-link")
                        if nested_a:
                            nested_a.decompose()

                        for br in soupDescription.find_all("br"):
                            br.replace_with("\n")

                    # Return the text content of the outer span tag, which now has '\n' instead of <br>
                    description = soupDescription.get_text(separator="")

                    # soup = BeautifulSoup(description, "html.parser")
                    # description = soup.get_text(separator="\n") + "\nHEHE"

                    if description is None:
                        description = ""
                else:
                    soup = BeautifulSoup(description, "html.parser")
                    description = soup.get_text(
                        separator="\n"
                    )  # This replaces <br> with newlines

                review_rating = float(
                    review.xpath('.//span[@class="lTi8oc z3HNkc"]/@aria-label')
                    .extract_first()
                    .split(" ")[1]
                )
                review_date = review.xpath(
                    './/span[@class="dehysf lTi8oc"]/text()'
                ).extract_first()
                # print("REVIEWER, DESCRIPTION", reviewer, description)

                ### BISMILLAH
                # IMAGE LINKS HERE WE GO!
                review_imgs_div = review.xpath(
                    './/div[@class="EDblX GpHuwc"]/div/a/div'
                )

                url_pattern = re.compile(r"url\((.*?)\)")

                it = 0
                for review_img_div in review_imgs_div:
                    it += 1
                    style_str = review_img_div.xpath("@style").extract_first()

                    # Find the URL
                    url = url_pattern.search(style_str).group(1)
                    url = re.sub(r"=w100-h100-p-n-k-no", "", url)
                    url += "=s2000-p-k-no"

                    self.download_image(reviewer, it, url)

                    # print(url + "=s2000-p-k-no", it, "\n")

                    # A SEPERATE LINE FOR EACH IMAGE
                    if it == 1:
                        yield {
                            "REVIEWER": reviewer,
                            "DESCRIPTION": description,
                            "rating": review_rating,
                            "review_date": review_date,
                            "IMAGE URL": url,
                        }
                    else:
                        yield {
                            "REVIEWER": reviewer,
                            "DESCRIPTION": description,
                            "rating": review_rating,
                            "review_date": review_date,
                            "IMAGE URL": url,
                        }

            # FIND NEXT PAGE TOKEN
            next_page_token_div = response.xpath('//*[@id="reviewSort"]/div/div[2]')
            next_page_token = next_page_token_div.xpath(
                "@data-next-page-token"
            ).extract_first()

            # CHECK IF REQUEST OR NOT
            # IF REQUEST THEN
            yield Request(
                url=response.request.url + f",next_page_token:{next_page_token}",
                headers=self.HEADERS,
                callback=self.get_total_iteration,
                dont_filter=True,
                meta={"iter": iter},
            )
